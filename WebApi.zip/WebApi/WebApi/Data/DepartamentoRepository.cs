﻿using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApi.Models;

namespace WebApi.Data
{
    public class DepartamentoRepository
    {
        private readonly string _connectionString;
        public DepartamentoRepository(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }
        public async Task<List<Departamento>> GetAll()
        {
            using (SqlConnection sql = new SqlConnection(_connectionString))
            {
                try
                {

                using (SqlCommand cmd = new SqlCommand("GetAllDepartamentos", sql))
                {
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    var response = new List<Departamento>();
                    await sql.OpenAsync();

                    using (var reader = await cmd.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            response.Add(MapToValue(reader));
                        }
                    }

                    return response;
                }
                }
                catch (Exception ex)
                {

                    throw;
                }
            }
        }

        private Departamento MapToValue(SqlDataReader reader)
        {
            return new Departamento()
            {
                Id = (int)reader["Id"],
                //Value1 = (int)reader["Value1"],
                Nombre = reader["Nombre"].ToString()
            };
        }

        public async Task<Departamento> GetById(int Id)
        {
            using (SqlConnection sql = new SqlConnection(_connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("GetDepartamentosById",sql))
                {
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("@Id", Id));
                    Departamento response = null;
                    await sql.OpenAsync();

                    using (var reader = await cmd.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            response = MapToValue(reader);
                        }
                    }
                    return response;
                }

            }
        }

        public async Task<object> Insert(Departamento departamento)
        {
            using (SqlConnection sql = new SqlConnection(_connectionString))
            {
                try
                {

                using (SqlCommand cmd = new SqlCommand("InsertDepartamentos", sql))
                {
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("@Nombre", departamento.Nombre));
                    await sql.OpenAsync();
                    await cmd.ExecuteNonQueryAsync();

                    return new ResultStatus { status = 1, message = "Registro Insertado Correctamente!." };
                }
                }
                catch (Exception ex)
                {                    
                    throw ex;
                }
            }
        }

        public async Task<object> DeleteById(int Id)
        {
            using (SqlConnection sql = new SqlConnection(_connectionString))
            {
                try
                {

                using (SqlCommand cmd = new SqlCommand("DeleteDepartamentosById", sql))
                {
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("@Id", Id));
                    await sql.OpenAsync();
                    await cmd.ExecuteNonQueryAsync();

                    return new ResultStatus { status = 3, message = "Registro Eliminado Satisfactoriamente!." };
                }
                }
                catch (Exception ex)
                {

                    throw ex;
                }

            }
        }

        public async Task<object> UpdateById(Departamento departamento)
        {
            using (SqlConnection sql = new SqlConnection(_connectionString))
            {
                try
                {

                using (SqlCommand cmd = new SqlCommand("UpdateDepartamentos", sql))
                {
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("@Id", departamento.Id));
                    cmd.Parameters.Add(new SqlParameter("@Nombre", departamento.Nombre));
                    await sql.OpenAsync();
                    await cmd.ExecuteNonQueryAsync();

                    return new ResultStatus { status = 2, message = "Registro Actualizado Correctamente!." };
                }
                }
                catch (Exception ex)
                {

                    throw ex;
                }

            }
        }
    }
}
