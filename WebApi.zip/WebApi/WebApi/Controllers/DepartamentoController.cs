﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using WebApi.Context;
using WebApi.Data;
using WebApi.Models;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    public class DepartamentoController : ControllerBase
    {
        private readonly AppDbContext context;
        private readonly DepartamentoRepository _repository;   
        public DepartamentoController(AppDbContext context, DepartamentoRepository repository)
        {
            this.context = context;
            this._repository = repository ?? throw new ArgumentNullException(nameof(repository));
        }

        [Route("GetAll")]
        [HttpGet]        
        public async Task<ActionResult<IEnumerable<Departamento>>> GetAll()
        {
            try
            {
                var res = await Task.Run(()=> _repository.GetAll());
                return Ok(res);            
            }
            catch (Exception ex)
            {
                throw new Exception("Error al retirnar datos", ex);
            }
        }

        // GET api/<DepartamentoController>/5
        [Route("GetById/{id}")]
        [HttpGet]
        public async Task<ActionResult<Departamento>> GetById(int id)
        {
            var response = await _repository.GetById(id);
            if(response == null)
            {
                return NotFound();
            }

            return response;
        }

        // POST api/<DepartamentoController>
        [Route("InsertDepartamento")]
        [HttpPost]
        public async Task<IActionResult> Post([FromBody] Departamento departamento)
        {
            try
            {
                var res = await Task.Run(() => _repository.Insert(departamento));
                return Ok(res);
            }
            catch (Exception ex)
            {

                throw new Exception("Error al insertar", ex);
            }
           
        }

        // PUT api/<DepartamentoController>/5
        [Route("UpdateDepartamento")]
        [HttpPost]
        public async Task<IActionResult> UpdateDepartamento([FromBody] Departamento departamento)
        {
            //if (departamento.Id == id)
            //{
            try
            {
                var res = await Task.Run(() => _repository.UpdateById(departamento));
                return Ok(res);
            }
            catch (Exception ex)
            {

                throw new Exception("Error al Actualizar", ex);
            }
         
        }

        // DELETE api/<DepartamentoController>/5
        [Route("DeleteDepartamento/{id}")]
        [HttpDelete]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                var res = await Task.Run(() => _repository.DeleteById(id));
                return Ok(res);
            }
            catch (Exception ex)
            {                
                throw new Exception("Error al eliminar", ex);
            }
           
        }
    }
}
